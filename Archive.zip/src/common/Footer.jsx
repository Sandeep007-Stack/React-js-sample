const Footer = () =>{
    return(
        <div className=" max-w-screen-xl mx-auto bg-gray-300 p-5">
            <h1>Footer</h1>
        </div>
    )
};

export default Footer;