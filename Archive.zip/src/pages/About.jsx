import { Fragment } from "react"

const About = ()=>{
    return(
        <Fragment>
            <div className="max-w-screen-xl mx-auto py-5">
                <h1>About</h1>
            </div>
        </Fragment>
    )
}

export default About